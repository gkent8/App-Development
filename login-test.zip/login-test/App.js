import { Text, SafeAreaView, TextInput, Button, StyleSheet, View } from 'react-native';
import React, {useState} from 'react';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [greeting, setGreeting] = useState('');

  const handlePress = () => {
    
      setGreeting(`Hello, ${firstName}!`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style = {styles.title}> Register Now </Text>

      <TextInput     
      style = {styles.textInput}
      onChangeText={text => setFirstName(text)}
      value={firstName}
      placeholder="First Name"
      />

      <TextInput
      style = {styles.textInput}
      onChangeText={text => setLastName(text)}
      value={lastName}
      placeholder="Last Name"
      />
      <TextInput
      style = {styles.textInput}
      onChangeText={text => setEmail(text)}
      value={email}
      placeholder="Email"
      />
      <TextInput
      style = {styles.textInput}
      onChangeText={text => setPassword(text)}
      value={password}
      placeholder="Password"
      />
      <View style = {styles.buttonContainer} >
      <View style = {styles.center}>
      <Button
      title="Sign Up!!"
      onPress={handlePress}
      />
      </View>
      </View>

      <View style = {styles.buttonContainer}>
      <Button
      title="Switch to Login"
      onPress={handlePress}
      />
      </View>

      {password && 
      <Text style={styles.paragraph}>
      {"     " + greeting + "! Thank you for Registering an account with us!!"}

      </Text>}      

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  textInput: { 
   height: 40,
   width: '75%',
   borderColor: 'gray', 
   borderWidth: 1,
   marginHorizontal: 'auto',
   marginVertical: 10,
   padding: 10,

  },
  
  title: {
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
  },

  buttonContainer: {
   height: 40,
   width: '40%',
   marginHorizontal: 'auto',

  },

});
